# Sobra — Calculadora de Gastos do Mês

App simples para controlar o salário e as contas do mês em reais.

## Como usar

1. Informe o **salário** do mês
2. Preencha os valores das **contas**
3. Marque o que já foi **pago**
4. Acompanhe quanto ainda **sobra**
5. Envie a lista no **WhatsApp**, baixe a planilha ou salve em PDF

## Funcionalidades

- Contas pré-cadastradas (Aluguel, Luz, Internet, etc.)
- Adicionar, editar e excluir contas
- Navegação por mês (cada mês é salvo separadamente)
- O próximo mês copia as contas automaticamente
- Botão **Enviar no WhatsApp**
- Baixar lista (.txt)
- Baixar planilha (.csv)
- Salvar PDF
- Tudo é salvo automaticamente no aparelho

## Link do site

Depois de ativar o GitHub Pages, o link será:

```
https://SEU-USUARIO.github.io/sobra
```

Substitua `SEU-USUARIO` pelo seu nome de usuário do GitHub.

## Como colocar no GitHub Pages

1. Crie um repositório chamado `sobra` (deixe **público**)
2. Envie o arquivo `index.html`
3. Vá em **Settings → Pages**
4. Em Source escolha a branch `main` (ou a que aparecer) e pasta `/ (root)`
5. Salve e aguarde 1–2 minutos
6. O link do site aparecerá na página de Pages

## Observação importante

Os dados de cada pessoa ficam salvos **somente no navegador dela**.  
Ninguém vê os gastos de outra pessoa.
