# Sobra — Calculadora de Gastos do Mês

Calculadora simples de gastos mensais em reais.

## Como usar

1. Informe o **salário** do mês
2. Preencha ou ajuste os valores das **contas**
3. Marque **Pago** ou **Não pago** em cada conta
4. Acompanhe o valor que ainda **sobra**

### Também é possível
- Adicionar, editar ou excluir contas
- Trocar de mês pelas setas (cada mês é salvo separadamente)
- O próximo mês copia as contas do anterior (todas como não pagas)
- Baixar lista (.txt), planilha (.csv) ou salvar PDF
- Tudo é salvo automaticamente no aparelho (localStorage)

## Link do site

Depois de ativar o GitHub Pages, o link será:

```
https://SEU-USUARIO.github.io/sobra
```

(Substitua `SEU-USUARIO` pelo seu nome de usuário do GitHub)

## Contas padrão

- Aluguel (R$ 700)
- Luz
- Internet
- Passagem
- Compras
- Internet Claro
- Escola

## Observação sobre os dados

Os dados ficam salvos **no navegador do aparelho**.  
Eles não são enviados para nenhum servidor.
